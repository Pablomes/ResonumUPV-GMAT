function I = Prob6MC(n)

    F = @(x, y, z) 2 .* z .* exp(-(x.^2));
    a = 0; b = 1;
    c = 1; d = 4; 

    xk = a + (b - a) * rand(n, 1);
    yk = c + (d - c) * rand(n, 1);
    zk = rand(n, 1).*xk;

    sum = 0;

    for i = 1:n
        sum = sum + F(xk(i), yk(i), zk(i));
    end

    I = 1.5 * (1 / n) * sum;
end