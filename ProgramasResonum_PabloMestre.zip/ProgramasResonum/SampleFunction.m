function [outs] = SampleFunction(parameters)
% [outs] = SampleFunction(parameters)
% Explicacion de la funcion
% PARAMETROS:
% parameters -> explicacion del parametro

outs = parameters;

end